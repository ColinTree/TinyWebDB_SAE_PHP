<?
use sinacloud\sae\Storage as Storage;
class backup{
    public function toExtJson($ex,$fileName,$id){
        header("Content-Type: text/json");header('Content-Disposition: attachment; filename="'.$fileName.'.json"');
        $results=$this->findByKVDB($ex,$id);
        $json=json_encode($results);
        exit($json);
    }
    public function toExtXml($ex,$fileName,$id){
        header("Content-Type: text/xml");header('Content-Disposition: attachment; filename="'.$fileName.'.xml"');
        echo "<?xml version=\"1.0\"  encoding=\"utf-8\" ?>\n";
        echo "<kvdb>\n";
        echo "\t<app>{$_SERVER['HTTP_APPNAME']}</app>\n";
        $results=$this->findByKVDB($ex,$id);
        foreach($results as $tag=>$value)echo "\t<pair><tag>{$tag}</tag><value>{$value}</value></pair>\n";$xml.="</kvdb>\n";
        exit;
    }
    public function findByKVDB($ex,$id){
        $kv=new SaeKV();$kv->init($id);
        $ret=$kv->pkrget(prefix.$ex,100);
        while(true){
            foreach($ret as $k=>$v)$results[substr($k,strlen(prefix))]=$v;
            end($ret);
            $start_key=key($ret);
            $i=count($ret);
            if($i<100)break;
            $ret=$kv->pkrget(prefix.$ex,100,$start_key);
        }
        return $results;
    }
    public function putToKVDB($fileName,$id){
        $kv=new SaeKV();$kv->init($id);
        $json=file_get_contents($fileName);
        $results=json_decode($json,true);
        foreach($results as $k=>$v)$kv->set(prefix.$k,$v);
        exit("恢复完成！");
    }
    public function toCSV($ex,$fileName,$id){
        header("Content-type:application/vnd.ms-excel; charset=gbk");header("Content-Disposition:filename=$fileName.csv");
        echo iconv('utf-8','gbk','"标签/Tag","值/value"'."\n");
        $results=$this->findByKVDB($ex,$id);
        foreach($results as $tag=>$value)echo iconv('utf-8','gbk',"\"".str_replace("\"","\"\"",$tag)."\",\"".str_replace("\"","\"\"",$value)."\"\n");
        exit;
    }
    public function toExcel($ex,$fileName,$id){
        $kv=new SaeKV();
        $ExcelDeleteAfterDownload=$kv->get("tinywebdbMANAGE_backup_excel_delete_after_download")=="on";
        $ExcelAutoWidth=$kv->get("tinywebdbMANAGE_backup_excel_auto_width")=="on";

        $s=new Storage();
        if(!in_array("files",$s->listBuckets())){$s->putBucket(ExcelStorageName);}
        $file_name="saestor://files/ExcelExportFiles/{$fileName}.xls";

        require_once('class/PHPExcel.php');require_once('class/PHPExcel/Writer/Excel5.php');
        $objPHPExcel=new PHPExcel();
        $objPHPExcel->getProperties()->setCreator($_SERVER['HTTP_APPNAME']." - TinyWebDB_SAE_PHP By ColinTree");
        $objPHPExcel->getProperties()->setLastModifiedBy($_SERVER['HTTP_APPNAME']." - TinyWebDB_SAE_PHP By ColinTree");
        $objPHPExcel->getProperties()->setTitle("Exported Data for SAE_APP: ".$_SERVER['HTTP_APPNAME'].".");
        $objPHPExcel->getProperties()->setDescription("Exported Data for SAE_APP: ".$_SERVER['HTTP_APPNAME'].".");
        $objPHPExcel->getActiveSheet()->setCellValue('A1',"标签/Tag");$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->setCellValue('B1',"值/value");$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
        if($ex!=""){$objPHPExcel->getActiveSheet()->setCellValue('D1',"前缀");$objPHPExcel->getActiveSheet()->setCellValue('E1',$ex);}
        $rowsCount=2;$results=$this->findByKVDB($ex,$id);
        foreach($results as $tag=>$value){$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowsCount,$tag);$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowsCount++,$value);}
        if($ExcelAutoWidth)foreach(["A","B","D","E"] as $column)$objPHPExcel->getActiveSheet()->getColumnDimension($column)->setAutoSize(true);
        $objWriter=new PHPExcel_Writer_Excel5($objPHPExcel);$objWriter->save($file_name);

        header("Content-Disposition:attachment;filename=$fileName.xls");$data=fopen($file_name,'rb');echo $contents=fread($data,filesize($file_name));

        if($ExcelDeleteAfterDownload){$s->deleteObject("files","ExcelExportFiles/{$fileName}.xls");}
        exit;
    }
}