<?
$backup=new backup();
$type=$_REQUEST['type'];$ex=$_REQUEST['ex'];
$fileName=date('Y_m_d_H_i_s');
if($ex<>'')$fileName=$fileName.'-'.$ex;
switch($type){
    case'Json': $backup->toExtJson($ex,$fileName,$id);break;
    case'Xml':  $backup->toExtXml($ex,$fileName,$id); break;
    case'CSV':  $backup->toCSV($ex,$fileName,$id);    break;
    case'Excel':$backup->toExcel($ex,$fileName,$id);  break;
    case'up':   $backup->putToKVDB($_FILES['upFile']['tmp_name'],$id); break;
}
?><div id="main"><div class="panel panel-default"><div class="panel-heading"><div class="panel-title">备份/恢复</div></div><div class="panel-body"><pre>======KVDB备份======<form name="readform" action="" method="get"><input type="hidden" name="a" value="backup"/><input type="hidden" name="noecho" value="true"/>备份类型：<select name="type" class="form-control"><option value="Json">Json</option><option value="Xml">Xml</option><option value="CSV">CSV</option><option value="Excel">Excel</option></select>key前缀：<input type="text" class="form-control" name="ex" /><input type="submit" class="btn btn-default" value="备份" /></form>======KVDB恢复======<form name="sendform" action="?a=backup&type=up" method="post" enctype="multipart/form-data">备份文件(目前仅限JSON格式)：<input type="file" class="form-control" name="upFile" id="file"/><input type="submit" class="btn btn-default" value="恢复"/></form></pre></div></div></div><div style="color:#bbb;padding-left:10px;font-size:80%">Backup/Restore By Cp0204 @ <a target="_blank" style="color:#bbb;text-decoration:underline" href="http://saebbs.com/forum.php?mod=viewthread&tid=3637">saebbs.com</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modify&amp;Merge By ColinTree @ <a target="_blank" style="color:#bbb;text-decoration:underline" href="http://www.colintree.cn">colintree.cn</a></div><?

use sinacloud\sae\Storage as Storage;
class backup{
    public static function findByKVDB($ex,$id){
        $kv=new SaeKV();$kv->init($id);
        $ret=$kv->pkrget(prefix.$ex,100);
        while(true){
            foreach($ret as $k=>$v)$results[substr($k,strlen(prefix))]=$v;
            end($ret);$start_key=key($ret);
            $i=count($ret);if($i<100)break;
            $ret=$kv->pkrget(prefix.$ex,100,$start_key);
        }
        return $results;
    }
    public static function toExtJson($ex,$fileName,$id){
        header('Content-Type: text/json');header('Content-Disposition: attachment; filename="'.$fileName.'.json"');
        $results=backup::findByKVDB($ex,$id);
        $json=json_encode($results);
        exit($json);
    }
    public static function toExtXml($ex,$fileName,$id){
        header('Content-Type: text/xml');header('Content-Disposition: attachment; filename="'.$fileName.'.xml"');
        echo '<?xml version="1.0"  encoding="utf-8" ?>',"\n";
        echo '<tinywebdb>',"\n";
        echo "\t",'<app>',$_SERVER['HTTP_APPNAME'],'</app>',"\n";
        $results=backup::findByKVDB($ex,$id);
        foreach($results as $tag=>$value)echo "\t",'<pair><tag>',$tag,'</tag><value>',$value,'</value></pair>',"\n";
        exit('</tinywebdb>');
    }
    public static function toCSV($ex,$fileName,$id){
        header('Content-type:application/vnd.ms-excel; charset=gbk');header('Content-Disposition:filename=$fileName.csv');
        echo iconv('utf-8','gbk','"标签/Tag","值/value"'."\n");
        $results=backup::findByKVDB($ex,$id);
        foreach($results as $tag=>$value)echo iconv('utf-8','gbk','"'.str_replace('"','""',$tag).'","'.str_replace('"','""',$value)."\"\n");
        exit;
    }
    public static function toExcel($ex,$fileName,$id){
        $kv=new SaeKV();
        $ExcelDeleteAfterDownload=$kv->get('tinywebdbMANAGE_backup_excel_delete_after_download')=='on';
        $ExcelAutoWidth=$kv->get('tinywebdbMANAGE_backup_excel_auto_width')=='on';

        $s=new Storage();
        if(!in_array('files',$s->listBuckets())){$s->putBucket('files');}
        $file_name='saestor://files/ExcelExportFiles/'.$fileName.'.xls';

        require_once('class/PHPExcel.php');require_once('class/PHPExcel/Writer/Excel5.php');
        $objPHPExcel=new PHPExcel();
        $objPHPExcel->getProperties()->setCreator($_SERVER['HTTP_APPNAME'].' - TinyWebDB_SAE_PHP By ColinTree');
        $objPHPExcel->getProperties()->setLastModifiedBy($_SERVER['HTTP_APPNAME'].' - TinyWebDB_SAE_PHP By ColinTree');
        $objPHPExcel->getProperties()->setTitle('Exported Data for SAE_APP: '.$_SERVER['HTTP_APPNAME'].'.');
        $objPHPExcel->getProperties()->setDescription('Exported Data for SAE_APP: '.$_SERVER['HTTP_APPNAME'].'.');
        $objPHPExcel->getActiveSheet()->setCellValue('A1','标签/Tag');$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->setCellValue('B1','值/value');$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
        if($ex!=''){$objPHPExcel->getActiveSheet()->setCellValue('D1','前缀');$objPHPExcel->getActiveSheet()->setCellValue('E1',$ex);}
        $rowsCount=2;$results=backup::findByKVDB($ex,$id);
        foreach($results as $tag=>$value){$objPHPExcel->getActiveSheet()->setCellValue('A'.$rowsCount,$tag);$objPHPExcel->getActiveSheet()->setCellValue('B'.$rowsCount++,$value);}
        if($ExcelAutoWidth)foreach(['A','B','D','E'] as $column)$objPHPExcel->getActiveSheet()->getColumnDimension($column)->setAutoSize(true);
        $objWriter=new PHPExcel_Writer_Excel5($objPHPExcel);$objWriter->save($file_name);

        header('Content-Disposition:attachment;filename=$fileName.xls');$data=fopen($file_name,'rb');echo $contents=fread($data,filesize($file_name));

        if($ExcelDeleteAfterDownload){$s->deleteObject('files','ExcelExportFiles/'.$fileName.'.xls');}
        exit;
    }
    public static function putToKVDB($fileName,$id){
        $kv=new SaeKV();$kv->init($id);
        $json=file_get_contents($fileName);
        $results=json_decode($json,true);
        foreach($results as $k=>$v)$kv->set(prefix.$k,$v);
        exit('恢复完成！');
    }
}