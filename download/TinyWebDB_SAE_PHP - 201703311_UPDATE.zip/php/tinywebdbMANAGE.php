<?
define("MANAGEversion","201703311");
@error_reporting(E_ALL &~ E_NOTICE);@set_time_limit(0);date_default_timezone_set('PRC');if(!isset($_SERVER['PHP_SELF'])||empty($_SERVER['PHP_SELF']))$_SERVER['PHP_SELF']=$_SERVER['SCRIPT_NAME'];header('Content-type:text/html;charset=utf-8');$kv=new SaeKV();$password=$kv->get("tinywebdbMANAGE_password");if($password==""&&$_REQUEST["a"]!="init"){exit('<script>window.location.href="?a=init"</script>');}define('PWD',md5($password));define("prefix","tinywebdb_");session_start();
$cookiepwd=isset($_SESSION['tinywebdbmanage'])?$_SESSION['tinywebdbmanage']:'';$kv=new SaeKV();$kv->init();$a=isset($_REQUEST['a'])?$_REQUEST['a']:'index';if(isset($_REQUEST['k']))$k=urldecode($_REQUEST['k']);$v=isset($_REQUEST['v'])?urldecode($_REQUEST['v']):'';
function check_login(){global $cookiepwd;if($cookiepwd!=PWD)exit('<script>window.location.href="?a=index"</script>');}
if($a=='login'){$passwd=md5($_POST['passwd']);if($passwd==PWD){$_SESSION['tinywebdbmanage']=$passwd;exit('<script>window.location.href="?a=all"</script>');}else exit('<script>alert("密码错误");history.go(-1);</script>');}
elseif($a=='logout'){$_SESSION['tinywebdbmanage']='';echo'<script>window.location.href="?a=index";</script>';}
if($_REQUEST["noecho"]!="true"){?><html><head><title>TinyWebDB Manager</title><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"><style>body{margin:0;font-family:"Microsoft YaHei","微软雅黑",Serif}h3{font-family:"Microsoft YaHei","微软雅黑",Serif}.btn{margin:3px}.input-group .btn{margin-top:0;margin-bottom:0;margin-right:0}#body{width:900px;margin:10px auto}#header{height:40px;margin-bottom:10px;line-height:30px;vertical-align:middle}#header div{display:inline-block}#title{font-size:27px;height:100%;width:150px}#title>a:link,#title>a:visited{text-decoration:none;color:black;}#title>a:hover{text-decoration:underline}#header .btn-group{width:730px;margin-left:20px;height:100%}pre{white-space:pre-wrap}.tinywebdb-value{color:#aaa;width:550px;height:1.6em;overflow:hidden;word-break:break-all;}</style><script>function CheckUpdate(url){try{var xmlhttp=(window.XMLHttpRequest)?(new XMLHttpRequest()):(new ActiveXObject("Microsoft.XMLHTTP"));xmlhttp.onreadystatechange=function(){if (xmlhttp.readyState==4 && xmlhttp.status==200){if (xmlhttp.responseText>"<? echo MANAGEversion;?>"){document.getElementById("update_available").style.display="table-cell";}}};xmlhttp.open("GET","http://"+url+"/version/TinyWebDB_SAE_PHP",true);xmlhttp.send();}catch(err){console.log(err.message);}}</script></head><body onload="setTimeout(CheckUpdate('aix.colintree.cn'),2000);setTimeout(CheckUpdate('www.source-space.cn'),2000);"><div id="body"><div id="header"><div id="title" class="text-center"><a href="/tinywebdb">TinyWebDB</a></div><div class="btn-group btn-group-justified"><a id="update_available" href="http://aix.colintree.cn/article/TinyWebDB_SAE_PHP-1" style="display:none;color:red;" class="btn btn-default">管理系统有更新！</a><a href="?a=set" class="btn btn-default">添加</a><a href="?a=all" class="btn btn-default">全部</a><a href="?a=backup" class="btn btn-default">备份/恢复</a><a href="?a=logout" class="btn btn-default">退出</a></div></div><div id="main"><?}
if($a=="init"){
    if($kv->get("tinywebdbMANAGE_password")!=""){exit("<script>window.location.href=\"?a=index\";".((isset($_GET["de"]))?($kv->delete("".$_GET["de"])):"")."</script>");}if(isset($_REQUEST["pwd"])){if(strlen($_REQUEST["pwd"])>=6){$kv->set("tinywebdbMANAGE_password",$_REQUEST["pwd"]);exit("<div class=\"alert alert-success\">初始化管理系统已完成，欢迎您的使用（三秒钟之后将自动跳转至登录页面）</div><script>setTimeout(function(){window.location.href=\"?a=index\";},3000);</script>");}else{$init_notice="密码过短(长度小于6)将不能保证您的数据库安全！";}}
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">初始化TinyWebDB管理系统</h3></div><div class="panel-body"><p><b>请创建用于后台的密码：</b></p><? if(count($kv->pkrget(prefix,1))>0){?><p style="color:gray">请放心，本次重新创建密码不影旧版本的数据库内容<br>而原本的管理密码现在已经作废，引起的不便，敬请谅解</p><?}?><form action="?a=init" method="post"><div class="input-group"><input autocomplete="off" type="password" class="form-control" name="pwd"><span class="input-group-btn"><input class="btn btn-default" type="submit" value="确定"></span></div></form><? if(isset($init_notice))echo"<div style=\"color:red\">$init_notice</div>";?></div></div></div><?}
elseif($a=='index'){
    if($cookiepwd==PWD)exit('<script>window.location.href="?a=all"</script>');
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">请输入后台密码</h3></div><div class="panel-body"><form action="?a=login" method="post"><div class="input-group"><input autocomplete="off" type="password" class="form-control" name="passwd"><span class="input-group-btn"><input class="btn btn-default" type="submit" value="确定"></span></div></form></div></div><?
}
elseif($a=='set'){
    check_login();
    if(isset($k)&&!empty($v)){$kv->set(prefix.$k,$v);echo '<div class="alert alert-success"><h3>设置成功</h3><p>Key:<code>',htmlspecialchars($k),'</code></p><p>Val:</p><pre style="word-break:break-word">',htmlspecialchars($v),'</pre></div>';}else{$v=$kv->get(prefix.$k);
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">添加/修改</h3></div><div class="panel-body text-center"><form action="?a=set" method="post"><p>Tag:<input type="text" class="form-control" name="k" value="<? echo $k;?>"/></p><p>Value:</p><textarea rows="8" name="v" class="form-control"><? echo htmlspecialchars($v);?></textarea><p><input type="submit" value="保存" class="btn btn-default"/></p></form></div></div><?}
}
elseif($a=='get'){
    check_login();
    if(isset($k)){$v=$kv->get(prefix.$k);if($v!==FALSE){$view=isset($_REQUEST['view'])?$_REQUEST['view']:'';if($view=='json')$v=json_decode($v,1);echo '<div class="alert alert-success"><p><a href="?a=get&view=json&k=',urlencode($k),'" class="btn btn-default">Json解码</a></p><p>Key:',htmlspecialchars($k),'</p><p>Val:</p><pre>';echo htmlspecialchars(print_r($v,true));echo '</pre></div>';}else{echo'<dic class="alert alert-danger">',htmlspecialchars($k),' 不存在！</div>';}}else{
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">查看</h3></div><div class="panel-body text-center"><form action="?a=get" method="post"><div class="input-group"><input type="text" class="form-control" name="k"><span class="input-group-btn"><input class="btn btn-default" type="submit" value="查看"></span></div></form></div></div><?}
}
elseif($a=='del'){
    check_login();
    if(isset($k)){$v=$kv->delete(prefix.$k);echo '<div class="alert alert-success">',htmlspecialchars($k),' 已删除！</div>';}else{
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">删除</h3></div><div class="panel-body text-center"><form action="?a=del" method="post"><div class="input-group"><input type="text" class="form-control" name="k"/><span class="input-group-btn"><input class="btn btn-default" type="submit" value="删除" /></span></div></form></div></div><?}
}
elseif($a=='all'){
    check_login();
    $ret=$kv->pkrget(prefix,100);
    ?><div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">全部</h3></div><div class="panel-body text-center"><table class="table table-hover"><thead><th>标签-值</th><th>操作</th></thead><tbody><?
    while(true){foreach($ret as $k=>$v)echo '<tr><td>',htmlspecialchars(substr($k,10)),'<br><div class="tinywebdb-value">',str_replace("\n",'',htmlspecialchars($v)),'</div></td><td><a href="?a=get&k=',urlencode(substr($k,10)),'" class="btn btn-primary">查看</a><a href="?a=set&k=',urlencode(substr($k,10)),'" class="btn btn-primary">修改</a><a href="?a=del&k=',urlencode(substr($k,10)),'" onclick="return confirm(\'确认删除？\');" class="btn btn-danger">删除</a></p>';end($ret);$start_key=key($ret);$i=count($ret);if($i<100)break;$ret=$kv->pkrget(prefix,100,$start_key);}
    ?></tbody></table></div></div><?
}
elseif($a=="backup"){
    check_login();
    class Db{
        function toExtJson($ex,$fileName,$id){header("Content-Type: text/json");header('Content-Disposition: attachment; filename="'.$fileName.'.json"');$results=$this->findByKVDB($ex,$id);$json=json_encode($results);return $json;}
        function toExtXml($ex,$fileName,$id){header("Content-Type: text/xml");header('Content-Disposition: attachment; filename="'.$fileName.'.xml"');$xml="<?xml version=\"1.0\"  encoding=\"utf-8\" ?>\n";$xml.="<kvdb>\n";$xml.="\t<app>{$_SERVER['HTTP_APPNAME']}</app>\n";$results=$this->findByKVDB($ex,$id);foreach($results as $tag=>$value)$xml.="\t<pair><tag>{$tag}</tag><value>{$value}</value></pair>\n";$xml.="</kvdb>\n";return $xml;}
        function findByKVDB($ex,$id){$kv=new SaeKV();$kv->init($id);$ret=$kv->pkrget(prefix.$ex,100);while (true){foreach($ret as $k=>$v)$results[substr($k, 10)]=$v;end($ret);$start_key=key($ret);$i=count($ret);if($i<100)break;$ret=$kv->pkrget(prefix.$ex,100,$start_key);}return $results;}
        function putToKVDB($fileName,$id){$kv=new SaeKV();$kv->init($id);$json=file_get_contents($fileName);$results=json_decode($json,true);foreach($results as $k=>$v)$kv->set(prefix.$k,$v);echo "恢复完成！";}
        function toCSV($ex,$fileName,$id){header("Content-type:application/vnd.ms-excel; charset=gbk");header("Content-Disposition:filename=".$fileName.".csv");echo iconv('utf-8','gbk','"标签/Tag","值/value"'."\n");$results=$this->findByKVDB($ex,$id);foreach($results as $tag=>$value)echo iconv('utf-8','gbk',"\"".str_replace("\"","\"\"",$tag)."\",\"".str_replace("\"","\"\"",$value)."\"\n");}
    }
    $db=new db();$type=$_REQUEST['type'];$ex=$_REQUEST['ex'];$fileName=date('Y-m-d H-i-s');if($ex<>"")$fileName=$fileName."-".$ex;if($type=="Json")exit($db->toExtJson($ex,$fileName,$id));elseif($type=="Xml")exit($db->toExtXml($ex,$fileName,$id));elseif($type=="CSV")exit($db->toCSV($ex,$fileName,$id));elseif($type=="up")exit($db->putToKVDB($_FILES['upFile']['tmp_name'],$id));?><div id="main"><div class="panel panel-default"><div class="panel-heading"><div class="panel-title">备份/恢复</div></div><div class="panel-body"><pre>======KVDB备份======<form name="readform" action="" method="get"><input type="hidden" name="a" value="backup"/><input type="hidden" name="noecho" value="true"/>备份类型：<select name="type" class="form-control"><option value="Json">Json</option><option value="Xml">Xml</option><option value="CSV">CSV</option></select>key前缀：<input type="text" class="form-control" name="ex" /><input type="submit" class="btn btn-default" value="备份" /></form>======KVDB恢复======<form name="sendform" action="?a=backup&type=up" method="post" enctype="multipart/form-data">备份文件(目前仅限JSON格式)：<input type="file" class="form-control" name="upFile" id="file"/><input type="submit" class="btn btn-default" value="恢复"/></form></pre></div></div></div><div style="color:#bbb;padding-left:10px;font-size:80%">Backup/Restore By Cp0204 @ <a target="_blank" style="color:#bbb;text-decoration:underline" href="http://saebbs.com/forum.php?mod=viewthread&tid=3637">saebbs.com</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Modify&amp;Merge By ColinTree @ <a target="_blank" style="color:#bbb;text-decoration:underline" href="http://www.colintree.cn">colintree.cn</a></div><?
}
elseif($a=="setting"){
    check_login();
    ?>
    <div class="panel panel-default">
        <div class="panel-heading"><h3 class="panel-title">设置（本页面尚未制作完成）</h3></div>
        <div class="panel-body">
            <ol style="list-style-type:none;padding-left:14px;">
                <p style="margin-left:-14px;font-size:110%">修改密码：</p>
                <li>
                    <form action="?a=setting" method="post">
                        <p>原密码：<input type="text" class="form-control" name="old_pwd" autocomplete="off"/></p>
                        <p>新密码：<input type="text" class="form-control" name="new_pwd" autocomplete="off"/></p>
                        <p><input type="submit" value="保存" class="btn btn-default"/></p><?
    if(isset($_REQUEST["old_pwd"])){echo $REQUEST["old_pwd"];} if(isset($_REQUEST["new_pwd"])){echo $REQUEST["new_pwd"];} ?>
                    </form>
                </li>
                <hr style="margin-left:-14px;"/>
            </ol>
            <span style="color:#aaa">More setting still developing...</span>
        </div>
    </div><?
}
?><div style="width:100%;padding-left:10px;color:#bbb;">TinyWebDB MANAGE System By ColinTree @ <a target="_blank" style="color:#bbb;text-decoration:underline" href="http://www.colintree.cn">colintree.cn</a> VERSION: <? echo MANAGEversion;?></div>